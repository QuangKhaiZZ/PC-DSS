const API_URL = "http://localhost:5170/api/brands";

async function request(url, options) {
  const response = await fetch(url, options);
  if (!response.ok) {
    const message = await response.text();
    throw new Error(message || `HTTP ${response.status}`);
  }
  if (response.status === 204) return null;
  const text = await response.text();
  return text ? JSON.parse(text) : null;
}

export const getBrands = () => request(API_URL);
export const getBrandById = (id) => request(`${API_URL}/${id}`);

export const createBrand = (data) =>
  request(API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });

export const updateBrand = (id, data) =>
  request(`${API_URL}/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });

export const deleteBrand = (id) =>
  request(`${API_URL}/${id}`, { method: "DELETE" });